import { BASE_URL } from "../base";

const API_ROOT = "organization";

export const org_profile_api = `${BASE_URL}/${API_ROOT}/profile/`;
