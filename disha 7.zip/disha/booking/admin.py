from django.contrib import admin
from .models import Booking,Ticket,DailyEarnings

# Register your models here.

admin.site.register(Ticket)
admin.site.register(DailyEarnings)

class BookingAdmin(admin.ModelAdmin):
    
    list_display = ['id','booking_id','trip','trip_datetime','passenger','num_passengers','price','booking_datetime','is_confirmed','is_paid']
    list_filter = ['trip','passenger','is_confirmed','is_paid']
    search_fields = ['trip','passenger','is_confirmed','is_paid']
    list_per_page = 10
    
admin.site.register(Booking, BookingAdmin)