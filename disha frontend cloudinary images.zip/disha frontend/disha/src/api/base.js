export const BASE_URL = "http://10.0.2.2:8000/api"
export const MEDIA_URL = "https://res.cloudinary.com/dckab8f6g/"
// https://res.cloudinary.com/dckab8f6g/

export const TICKET_URL = "http://10.0.2.2:8000"