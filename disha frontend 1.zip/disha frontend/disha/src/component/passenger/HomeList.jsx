import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  Image,
  Alert,
  TouchableOpacity,
} from "react-native";
import { useSelector } from "react-redux";
import { MEDIA_URL } from "../../api/base";
import { getHome } from "../../api/passener/request";
import { showMessage } from "react-native-flash-message";

const HomeList = ({navigation}) => {
  const token = useSelector((state) => state.auth.token.token);
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token) return;
    fetchHome();
  }, [token]);

  const fetchHome = async () => {
    try {
      const res = await getHome(token);
      if (res.status === "success" && res.data && res.data.vehicle_trip_data) {
        setTrips(res.data.vehicle_trip_data);
      } else {
        console.log("No trip data found.");
      }
    } catch (error) {
      console.log("Home list error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleBookingClick = (trip) => {
    navigation.navigate('ToBook',{book_detail:trip})
    showMessage({
      message: "Success",
      description: "Redirecting to book details",
      type: "success",
    });
  };

  if (loading) {
    return (
      <View className="flex-1 items-center justify-center">
        <Text className="text-lg text-primary">Loading...</Text>
      </View>
    );
  }

  return (
    <ScrollView className="flex-1 p-4 bg-gradient-to-b from-primary to-darker">
      {trips.length === 0 ? (
        <Text className="text-center text-lg text-secondary">
          No trips available.
        </Text>
      ) : (
        trips.map((trip) => (
          <View
            key={trip.id}
            className="bg-primary p-4 mb-6 rounded-lg shadow-md hover:bg-secondary hover:scale-[1.02] transition-transform duration-300 ease-in-out"
          >
            <Image
              source={{ uri: `${MEDIA_URL}${trip.vehicle_image}` }}
              className="w-full h-36 rounded-md mb-4"
              resizeMode="cover"
            />
            <View className="flex-row justify-between items-center mb-2">
              <Text className="text-lg text-background font-bold">
                {trip.from_location} ➡️ {trip.to_location}
              </Text>
              <Text className="text-xs text-background font-semibold">
                {trip.is_completed ? "Completed" : "In Progress"}
              </Text>
            </View>

            <View className="flex-row justify-between mb-2">
              <View>
                <Text className="text-sm text-background font-semibold">
                  Date: {new Date(trip.start_datetime).toLocaleDateString()}
                </Text>
                <Text className="text-sm text-background">
                  Time: {new Date(trip.start_datetime).toLocaleTimeString()}
                </Text>
              </View>
              <View className="text-right">
                <Text className="text-sm text-background">
                  Org: {trip.organization}
                </Text>
                <Text className="text-sm text-background">
                  Driver: {trip.driver}
                </Text>
              </View>
            </View>

            <View className="flex-row justify-between mb-2">
              <Text className="text-sm text-background">
                Seats: {trip.available_seat}
              </Text>
              <Text className="text-sm text-background">
                Price: {trip.trip_price.price || "N/A"}
              </Text>
            </View>

            <TouchableOpacity
              onPress={()=>handleBookingClick(trip)}
              className="bg-accent py-2 px-4 rounded-md self-center mt-4 hover:bg-opacity-80 active:bg-opacity-70 transition duration-200"
            >
              <Text className="text-white font-bold text-sm text-center">
                Book Seat
              </Text>
            </TouchableOpacity>
          </View>
        ))
      )}
    </ScrollView>
  );
};

export default HomeList;
