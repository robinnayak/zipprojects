import React, { useEffect, useState } from "react";
import { View, Text, TouchableOpacity } from "react-native";
import { getTicketData } from "../../../api/booking/request";
import { handleApiError } from "../../../utils/errorHandler";

const TicketList = ({ navigation, token }) => {
  const [tickets, setTickets] = useState([]);

  useEffect(() => {
    if (!token) return;
    fetchTicket();
  }, [token]);

  const fetchTicket = async () => {
    try {
      const res = await getTicketData(token);
      setTickets(res.data);
    } catch (error) {
      console.error("Error fetching tickets:", error);
      handleApiError(error);
    }
  };

  const handleTicketClick = (ticket) => {
    navigation.navigate("TicketDetail", { ticket });
  };

  return (
    <View className="p-4">
      {tickets.length === 0 ? (
        <Text className="text-gray-500 text-center">No tickets available</Text>
      ) : (
        tickets.map((ticket) => (
          <TouchableOpacity
            key={ticket.id}
            className="border-b border-gray-300 py-2"
            onPress={() => handleTicketClick(ticket)}
          >
            <Text className="text-base font-semibold">{ticket.ticket_id}</Text>
            <Text className="text-sm text-gray-600">
              Booking ID: {ticket.booking_id}
            </Text>
            <Text className="text-xs text-gray-400">
              Ticket ID: {ticket.id}
            </Text>
          </TouchableOpacity>
        ))
      )}
    </View>
  );
};

export default TicketList;
