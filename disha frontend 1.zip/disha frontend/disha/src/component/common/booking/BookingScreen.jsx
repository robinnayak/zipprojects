import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const BookingScreen = () => {
  return (
    <View>
      <Text>BookingScreen</Text>
    </View>
  )
}

export default BookingScreen

