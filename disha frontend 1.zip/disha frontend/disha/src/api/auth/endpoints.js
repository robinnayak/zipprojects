import { BASE_URL } from "../base";

const API_ROOT = "auth";

export const login_api = `${BASE_URL}/${API_ROOT}/login/`;
export const logout_api = `${BASE_URL}/${API_ROOT}/logout/`;
export const register_api = `${BASE_URL}/${API_ROOT}/register/`;