import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Alert,
} from "react-native";
import React, { useState } from "react";
import { useNavigation } from "@react-navigation/native";
import { registerUser } from "../../api/auth/request";
import LoadingAnimation from "../../component/common/LoadingAnimation";
import { handleApiError } from "../../utils/errorHandler";
import { showMessage } from "react-native-flash-message";
import CustomInput from "../../component/common/commonFormComponent/CustomInput";
import CustomCheckbox from "../../component/common/commonFormComponent/CustomCheckbox";

const RegisterScreen = () => {
  const navigation = useNavigation();
  const [user, setUser] = useState({
    username: "",
    email: "",
    password: "",
    password2: "",
    license_number: "",
    is_organization: false,
    is_driver: false,
    is_passenger: false,
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (name, value) => {
    setUser({ ...user, [name]: value });
  };

  const handleRegister = async () => {
    if (user.password !== user.password2) {
      showMessage({
        message: "Error",
        description: "Passwords do not match",
        type: "danger",
      });
      return;
    }

    setLoading(true);

    try {
      const response = await registerUser(user); // Use Axios request
      setLoading(false);
      showMessage({
        message: "Success",
        description: `Registration successful ${response.data.user.username} `,
        type: "success",
      });
      navigation.navigate("Login");
    } catch (error) {
      handleApiError(error)
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <LoadingAnimation />; // Show loading animation while loading is true
  }

  return (
    <ScrollView className="flex-1 bg-background">
      <View className="flex h-full justify-center p-5 bg-background">
        <View className="flex bg-primary flex-col justify-center items-center mb-8">
          <Text className="text-3xl font-bold text-primary-on-dark pt-2 mb-4">
            Register with Disha
          </Text>
        </View>

        <View className="shadow-lg bg-primary p-6 rounded-lg">
          <CustomInput
            label="Username"
            value={user.username}
            onChangeText={(value) => handleChange("username", value)}
            placeholder="Enter your username"
          />
          <CustomInput
            label="Email"
            value={user.email}
            onChangeText={(value) => handleChange("email", value)}
            placeholder="Enter your email"
          />
          <CustomInput
            label="Password"
            value={user.password}
            onChangeText={(value) => handleChange("password", value)}
            placeholder="Enter your password"
            secureTextEntry
          />
          <CustomInput
            label="Confirm Password"
            value={user.password2}
            onChangeText={(value) => handleChange("password2", value)}
            placeholder="Confirm your password"
            secureTextEntry
          />

          <CustomCheckbox
            label="Are you an Organization?"
            value={user.is_organization}
            onValueChange={(value) => handleChange("is_organization", value)}
          />
          <CustomCheckbox
            label="Are you a Driver?"
            value={user.is_driver}
            onValueChange={(value) => handleChange("is_driver", value)}
          />
          <CustomCheckbox
            label="Are you a Passenger?"
            value={user.is_passenger}
            onValueChange={(value) => handleChange("is_passenger", value)}
          />

          {/* Display License Number field only when Driver is checked */}
          {user.is_driver && (
            <CustomInput
              label="License Number"
              value={user.license_number}
              onChangeText={(value) => handleChange("license_number", value)}
              placeholder="Enter your license number"
            />
          )}

          <TouchableOpacity
            onPress={handleRegister}
            className="bg-primary-on-dark py-3 rounded-xl mt-5"
            activeOpacity={0.7}
          >
            <Text className="text-center text-primary font-bold text-lg">
              Register
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => navigation.navigate("Login")}
            className="mt-6"
          >
            <Text className="text-center text-accent text-lg">
              Already have an account? Login here
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

export default RegisterScreen;

const styles = StyleSheet.create({});
