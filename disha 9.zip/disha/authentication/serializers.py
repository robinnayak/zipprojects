from rest_framework import serializers
from django.core.exceptions import ValidationError
from .models import CustomUser, Profile, Location, Driver, Organization, Passenger

# CustomUser Serializer
class CustomUserSerializer(serializers.ModelSerializer):
    password2 = serializers.CharField(style={'input_type': 'password'}, write_only=True)

    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'password', 'password2', 'email', 'is_organization', 'is_driver', 'is_passenger']
        extra_kwargs = {'password': {'write_only': True}}

    def validate(self, data):
        # Validate phone number length if provided
        if 'profile' in data:
            phone_number = data['profile'].get('phone_number')
            if phone_number and len(phone_number) != 10:
                raise serializers.ValidationError("Phone number must be 10 digits")

        # Check if username already exists
        if CustomUser.objects.filter(username=data['username']).exists():
            raise serializers.ValidationError("Username already exists")
        
        # Ensure password and password2 match
        if data['password'] != data['password2']:
            raise serializers.ValidationError("Passwords must match")
        
        return data

    def create(self, validated_data):
        # Remove password2 from validated data since it's not needed for user creation
        validated_data.pop('password2', None)
        
        # Create the CustomUser instance
        user = CustomUser.objects.create_user(**validated_data)
        return user

    def update(self, instance, validated_data):
        # Update the CustomUser instance
        instance = super().update(instance, validated_data)
        return instance


# CustomUser Login Serializer
class CustomUserLoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()

    def validate(self, data):
        # Fetch user by username
        user = CustomUser.objects.filter(username=data['username']).first()

        # Validate user existence and password correctness
        if not user or not user.check_password(data['password']):
            raise serializers.ValidationError("Invalid username or password")
        
        return data


# Location Serializer
class LocationSerializer(serializers.ModelSerializer):
    user = CustomUserSerializer(read_only=True)

    class Meta:
        model = Location
        fields = '__all__'

    def create(self, validated_data):
        # Retrieve user from the context
        username = self.context['username']
        user = CustomUser.objects.get(username=username)

        # Create or update the Location instance
        location, created = Location.objects.update_or_create(
            user=user,
            defaults=validated_data
        )
        return location


# Organization Serializer
class OrganizationSerializer(serializers.ModelSerializer):
    username = serializers.ReadOnlyField(source='user.username')
    email = serializers.ReadOnlyField(source='user.email')
    # user = CustomUserSerializer(read_only=True)

    class Meta:
        model = Organization
        fields = '__all__'

    def create(self, validated_data):
        # Retrieve user from the context
        username = self.context['username']
        user = CustomUser.objects.get(username=username)
        validated_data['user'] = user

        # Create the Organization instance
        organization = Organization.objects.create(**validated_data)
        return organization
    
    def update(self, instance, validated_data):
        # Extract and update user data if provided
        user_data = validated_data.pop('user', None)
        if user_data:
            CustomUser.objects.filter(pk=instance.user.pk).update(**user_data)
        
        # Update the Organization instance with the remaining data
        for attr, value in validated_data.items():
            setattr(instance, attr, value)
        instance.save()
        
        return instance




# Driver Serializer
class DriverSerializer(serializers.ModelSerializer):
    username = serializers.ReadOnlyField(source='user.username')
    email = serializers.ReadOnlyField(source='user.email')
    
    class Meta:
        model = Driver
        fields = '__all__'

    def create(self, validated_data):
        # Retrieve user from the context
        username = self.context['username']
        user = CustomUser.objects.get(username=username)
        validated_data['user'] = user

        # Create the Driver instance
        driver = Driver.objects.create(**validated_data)
        return driver

    def update(self, instance, validated_data):
        # Handle specific context for organization assignment if applicable
        check_organization = self.context.get('check_organization')
        org_email = self.context.get('org_email')
        if check_organization and org_email:
            organization = Organization.objects.get(user__email=org_email)
            instance.organization = organization
        
        # Update the Driver instance with the remaining data
        return super().update(instance, validated_data)


# Passenger Serializer
class PassengerSerializer(serializers.ModelSerializer):
    username = serializers.ReadOnlyField(source='user.username')
    email = serializers.ReadOnlyField(source='user.email')
    
    class Meta:
        model = Passenger
        fields = '__all__'

    def validate_loyalty_points(self, value):
        # Validate that loyalty points are not negative
        if value < 0:
            raise serializers.ValidationError("Loyalty points cannot be negative.")
        return value

    def create(self, validated_data):
        # Retrieve user from the context
        username = self.context['username']
        user = CustomUser.objects.get(username=username)
        validated_data['user'] = user

        # Create the Passenger instance
        passenger = Passenger.objects.create(**validated_data)
        return passenger
    
    def update(self, instance, validated_data):
        # Validate loyalty points logic during update
        loyalty_points = validated_data.get('loyalty_points', instance.loyalty_points)
        if loyalty_points < 0 or ('redeem_points' in self.initial_data and loyalty_points > instance.loyalty_points):
            raise serializers.ValidationError("Invalid loyalty points operation.")
        
        # Update the Passenger instance with the remaining data
        return super().update(instance, validated_data)
